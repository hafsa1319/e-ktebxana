
            

      $('<article class="PageArea">\
         <div class="Container">\
         <div class="row">\
            <div class="col-12 ">\
               <div class="Account">\
                  <div class="Left">\
                     <div class="Avatar">\
                        <img src=""/>\
                     </div>\
                     <div class="Info">\
                        <span class="Name"></span>\
                        <span class="Id"></span>\
                     </div>\
                     <div class="NavList">\
                        <a href="/my-account" class="Btn Active">\
                           <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 32 32" style="enable-background:new 0 0 32 32;" xml:space="preserve">\
                           <path id="user_1_" d="M31.36,31h-0.72c0-6.432-4.777-12.232-11.359-13.792c-0.15-0.036-0.261-0.163-0.275-0.317 c-0.015-0.153,0.071-0.299,0.212-0.362c2.861-1.273,4.71-4.116,4.71-7.241c0-4.371-3.556-7.927-7.927-7.927 c-4.372,0-7.928,3.556-7.928,7.927c0,3.125,1.849,5.968,4.711,7.241c0.141,0.063,0.226,0.209,0.212,0.362 c-0.014,0.154-0.125,0.281-0.275,0.317C6.137,18.768,1.36,24.568,1.36,31H0.64c0-6.46,4.574-12.312,11.002-14.248 c-2.634-1.539-4.291-4.375-4.291-7.465c0-4.768,3.879-8.647,8.648-8.647c4.768,0,8.647,3.879,8.647,8.647 c0,3.09-1.656,5.926-4.29,7.465C26.786,18.688,31.36,24.54,31.36,31z"/>\
                           <rect id="_Transparent_Rectangle" style="fill:none;" width="32" height="32"/>\
                           </svg>\
                           <span>'+pageLang(1970)+'</span>\
                        </a>\
                        <a href="/my-avatar" class="Btn"> \
                           <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">\
                           <g>\
                              <g>\
                                 <path d="M206.695,210.443c-4.016-4.705-11.265-4.705-15.281,0c-11.566,13.55-30.311,44.692-11.819,44.692h38.918\
                                    C237.005,255.134,218.26,223.993,206.695,210.443z"/>\
                              </g>\
                           </g>\
                           <g>\
                              <g>\
                                 <path d="M320.587,210.443c-4.016-4.705-11.265-4.705-15.279,0c-11.566,13.55-30.311,44.692-11.819,44.692h38.918\
                                    C350.898,255.135,332.153,223.994,320.587,210.443z"/>\
                              </g>\
                           </g>\
                           <g>\
                              <g>\
                                 <path d="M261.2,246.394c-2.733-3.202-7.668-3.202-10.401,0c-7.872,9.225-20.631,30.421-8.044,30.421h26.49\
                                    C281.832,276.815,269.073,255.618,261.2,246.394z"/>\
                              </g>\
                           </g>\
                           <g>\
                              <g>\
                                 <path d="M293.683,283.82h-15.819v7.007c0,3.547-2.875,6.423-6.423,6.423s-6.423-2.875-6.423-6.423v-7.007h-18.033v7.007\
                                    c0,3.547-2.875,6.423-6.423,6.423s-6.423-2.875-6.423-6.423v-7.007H218.32c-3.547,0-6.423,2.875-6.423,6.423\
                                    c0,24.32,19.785,44.105,44.105,44.105s44.105-19.785,44.105-44.105C300.105,286.696,297.23,283.82,293.683,283.82z"/>\
                              </g>\
                           </g>\
                           <g>\
                              <g>\
                                 <path d="M510.341,155.431c2.235-3.063,2.209-7.227-0.066-10.261c-2.275-3.035-6.264-4.229-9.831-2.945l-99.091,35.7v-47.633\
                                    l52.64-72.134c2.236-3.063,2.209-7.227-0.064-10.261c-2.274-3.035-6.264-4.234-9.831-2.944l-81.46,29.347l37.694-51.655\
                                    c2.237-3.065,2.208-7.233-0.07-10.268c-2.278-3.035-6.273-4.224-9.841-2.933L256.001,58.155L121.579,9.445\
                                    c-3.567-1.292-7.563-0.104-9.841,2.933c-2.278,3.035-2.307,7.203-0.07,10.268l37.695,51.655l-81.46-29.348\
                                    c-3.567-1.289-7.556-0.091-9.831,2.944c-2.274,3.034-2.3,7.198-0.064,10.261l52.64,72.134v47.633l-99.091-35.7\
                                    c-3.567-1.289-7.556-0.092-9.831,2.945c-2.275,3.034-2.301,7.198-0.066,10.261L110.646,304.78v76.928l-52.64,72.133\
                                    c-2.236,3.063-2.209,7.227,0.064,10.261c2.275,3.035,6.264,4.233,9.831,2.944l81.46-29.347l-37.695,51.655\
                                    c-2.237,3.065-2.208,7.233,0.07,10.268c2.279,3.038,6.274,4.225,9.841,2.933L256,453.847l134.421,48.709\
                                    c0.962,0.349,1.956,0.517,2.939,0.517c2.66,0,5.239-1.232,6.903-3.45c2.278-3.035,2.307-7.203,0.07-10.268L362.639,437.7\
                                    l81.46,29.347c1.025,0.369,2.073,0.556,3.129,0.509c4.683-0.096,8.449-3.921,8.449-8.628c0-2.107-0.755-4.038-2.009-5.537\
                                    l-52.313-71.684v-76.931L510.341,155.431z M401.355,196.27l78.44-28.26l-78.44,107.488V196.27z M32.206,168.01l78.44,28.26v79.229\
                                    L32.206,168.01z M423.447,441.262l-81.459-29.347c-3.567-1.288-7.556-0.092-9.831,2.943c-2.274,3.035-2.3,7.2-0.066,10.263\
                                    l37.639,51.579L258.94,436.553c-1.9-0.688-3.98-0.688-5.88,0L142.268,476.7l37.639-51.579c2.236-3.063,2.209-7.227-0.064-10.261\
                                    c-1.664-2.221-4.245-3.457-6.907-3.457c-0.977,0-1.965,0.168-2.924,0.512l-81.457,29.347l37.694-51.653\
                                    c1.078-1.476,1.658-3.259,1.658-5.087V127.479c0-1.828-0.581-3.611-1.658-5.087L88.553,70.737l81.46,29.347\
                                    c3.567,1.288,7.556,0.092,9.831-2.944c2.274-3.034,2.3-7.198,0.064-10.261L142.27,35.3l110.792,40.148\
                                    c1.9,0.688,3.98,0.688,5.88,0L369.732,35.3l-37.639,51.579c-2.234,3.063-2.208,7.227,0.066,10.263\
                                    c2.275,3.035,6.268,4.227,9.831,2.943l81.46-29.347l-37.695,51.655c-1.078,1.476-1.658,3.259-1.658,5.087v62.728v111.758v82.557\
                                    c0,1.828,0.581,3.611,1.658,5.087L423.447,441.262z"/>\
                              </g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           </svg>\
                           <span>'+pageLang(1971)+'</span>\
                        </a>\
                        <a href="/my-background" class="Btn"> \
                           <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"\
                              viewBox="0 0 511.997 511.997" style="enable-background:new 0 0 511.997 511.997;" xml:space="preserve">\
                           <g>\
                              <g>\
                                 <g>\
                                    <path d="M34.17,447.316c0,15.698,12.771,28.469,28.469,28.469c15.698,0,28.469-12.771,28.469-28.469\
                                       s-12.771-28.469-28.469-28.469C46.941,418.847,34.17,431.618,34.17,447.316z M74.994,447.316c0,6.812-5.542,12.355-12.355,12.355\
                                       c-6.812,0-12.355-5.542-12.355-12.355s5.542-12.355,12.355-12.355C69.452,434.961,74.994,440.504,74.994,447.316z"/>\
                                    <path d="M503.977,177.456l-31.951-31.951c-3.148-3.147-8.249-3.147-11.395,0c-3.147,3.147-3.147,8.249,0,11.394l1.807,1.807\
                                       l-87.757,87.758c-3.147,3.147-3.147,8.249,0,11.395c1.574,1.573,3.635,2.36,5.698,2.36c2.062,0,4.124-0.786,5.698-2.36\
                                       l87.757-87.757l18.749,18.749c4.361,4.359,4.361,11.453,0,15.813L373.058,324.186L187.785,138.913L307.307,19.39\
                                       c2.113-2.112,4.92-3.276,7.907-3.276s5.795,1.164,7.906,3.275l10.191,10.191l-87.757,87.758c-3.147,3.147-3.147,8.249,0,11.394\
                                       c1.573,1.573,3.635,2.36,5.697,2.36s4.124-0.786,5.697-2.36l87.758-87.757l20.918,20.918l-87.757,87.758\
                                       c-3.147,3.147-3.147,8.249,0,11.394c1.574,1.573,3.637,2.36,5.698,2.36s4.124-0.786,5.698-2.36l87.757-87.757l21.385,21.385\
                                       l-87.757,87.758c-3.147,3.147-3.147,8.249,0,11.395c1.574,1.573,3.635,2.36,5.698,2.36c2.062,0,4.124-0.786,5.698-2.36\
                                       l87.757-87.757l20.367,20.367l-87.757,87.758c-3.147,3.147-3.147,8.249,0,11.395c1.574,1.573,3.637,2.36,5.698,2.36\
                                       s4.124-0.786,5.698-2.36l88.234-88.235c2.891,1.132,6.303,0.534,8.64-1.802c3.147-3.147,3.147-8.249,0-11.394L350.418,23.896\
                                       c-0.003-0.003-0.006-0.008-0.01-0.011s-0.008-0.006-0.011-0.01L334.519,7.997C329.361,2.839,322.506,0,315.214,0\
                                       c-7.29,0-14.145,2.839-19.302,7.995L176.006,127.902c-5.999-3.884-13.051-4.48-18.579-1.589c-0.055,0.028-0.107,0.06-0.162,0.089\
                                       c-0.381,0.205-0.758,0.42-1.124,0.66c-0.167,0.107-0.324,0.229-0.487,0.343c-0.259,0.185-0.522,0.362-0.771,0.564\
                                       c-0.423,0.341-0.833,0.7-1.219,1.087l-17.614,17.614l-14.281,14.282c-5.116,5.117-5.964,13.444-2.107,20.721l35.183,66.386\
                                       c12.551,23.682,8.702,51.876-9.579,70.157c-15.444,15.444-31.641,28.596-49.514,40.205c-3.732,2.424-4.791,7.414-2.368,11.146\
                                       c2.424,3.732,7.415,4.791,11.146,2.368c18.828-12.23,35.881-26.075,52.13-42.325c23.317-23.317,28.309-59.122,12.423-89.098\
                                       l-35.183-66.386c-0.515-0.972-0.568-1.685-0.546-1.972l8.394-8.394l206.46,206.461l-8.444,8.444\
                                       c-0.29,0.02-0.978-0.031-1.922-0.521l-67.561-35.038c-29.825-15.467-65.377-10.343-88.472,12.751L171.8,365.867\
                                       c-27.106,27.106-45.981,57.363-63.117,101.168c-2.283,5.838-5.697,11.054-10.145,15.502c-8.785,8.785-20.59,13.518-33.287,13.34\
                                       c-13.447-0.193-26.051-5.805-35.488-15.801c-17.489-18.523-18.25-47.155-1.734-65.18c4.41-4.814,9.664-8.544,15.616-11.084\
                                       c12.341-5.268,23.456-10.538,33.983-16.109c3.933-2.082,5.434-6.958,3.353-10.89c-2.081-3.933-6.958-5.434-10.89-3.353\
                                       c-10.128,5.36-20.847,10.44-32.772,15.531c-8.077,3.449-15.199,8.502-21.17,15.019c-22.194,24.222-21.359,62.495,1.898,87.13\
                                       c12.452,13.189,29.135,20.595,46.974,20.851c0.316,0.004,0.628,0.006,0.944,0.006c16.715,0,32.299-6.394,43.969-18.065\
                                       c6.031-6.031,10.659-13.106,13.759-21.026c16.273-41.605,34.068-70.208,59.504-95.643l10.009-10.009\
                                       c18.105-18.103,46.096-22.06,69.657-9.841l67.561,35.038c7.342,3.808,15.404,2.943,20.546-2.199l31.947-31.947\
                                       c3.485-3.485,5.077-8.512,4.367-13.791c-0.401-2.978-1.52-5.9-3.218-8.546l119.911-119.911\
                                       C514.619,205.416,514.619,188.098,503.977,177.456z M359.603,358.828L153.142,152.367l11.728-11.727\
                                       c0.025-0.001,0.057-0.002,0.089-0.003c0.014,0,0.029,0,0.044,0c0.073,0.001,0.154,0.008,0.236,0.016\
                                       c0.052,0.006,0.103,0.012,0.16,0.021c0.041,0.006,0.084,0.015,0.126,0.024c0.101,0.02,0.206,0.045,0.32,0.078\
                                       c0.015,0.004,0.031,0.01,0.046,0.014c0.131,0.04,0.269,0.088,0.414,0.146c0.017,0.006,0.034,0.014,0.052,0.021\
                                       c0.136,0.056,0.279,0.124,0.424,0.198c0.034,0.017,0.069,0.034,0.103,0.053c0.129,0.069,0.262,0.15,0.396,0.235\
                                       c0.05,0.032,0.101,0.062,0.153,0.097c0.128,0.086,0.258,0.185,0.389,0.287c0.054,0.042,0.107,0.08,0.161,0.124\
                                       c0.182,0.15,0.365,0.313,0.548,0.496l2.16,2.16l196.667,196.667c0.002,0.002,0.003,0.003,0.005,0.005l2.156,2.156\
                                       c1.546,1.546,1.86,3.105,1.815,3.658L359.603,358.828z"/>\
                                 </g>\
                              </g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           <g>\
                           </g>\
                           </svg>\
                           <span>'+pageLang(1972)+'</span>\
                        </a>\
                     </div>\
                  </div>\
                  <div class="Right">\
                     <div class="Title"> '+pageLang(1970)+' </div>\
                     <div class="Form">\
                        <div class="InputItem Lock">\
                           <div class="View">\
                              <span> '+pageLang(1975)+' </span>\
                              <div class="Input" name="UserId"></div>\
                              <div class="BtnEdit"> \
                                 <svg width="21px" height="21px" viewBox="0 0 21 21" xmlns="http://www.w3.org/2000/svg"><g fill="none" fill-rule="evenodd" transform="translate(4 1)"><path d="m2.5 8.5-.00586729-1.99475098c-.00728549-4.00349935 1.32800361-6.00524902 4.00586729-6.00524902s4.0112203 2.00174967 4.0000699 6.00524902v1.99475098m-8.0000699 0h8.0225317c1.0543618 0 1.9181652.81587779 1.9945143 1.8507377l.0054778.1548972-.0169048 6c-.0031058 1.1023652-.8976224 1.9943651-1.999992 1.9943651h-8.005627c-1.1045695 0-2-.8954305-2-2v-6c0-1.1045695.8954305-2 2-2z" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/><circle cx="6.5" cy="13.5" fill="currentColor" r="1.5"/></g></svg>\
                              </div>\
                           </div>\
                        </div>\
                        <div class="InputItem Lock">\
                           <div class="View">\
                              <span> '+pageLang(1976)+' </span>\
                              <div class="Input" name="Mail"></div>\
                              <div class="BtnEdit"> \
                                 <svg width="21px" height="21px" viewBox="0 0 21 21" xmlns="http://www.w3.org/2000/svg"><g fill="none" fill-rule="evenodd" transform="translate(4 1)"><path d="m2.5 8.5-.00586729-1.99475098c-.00728549-4.00349935 1.32800361-6.00524902 4.00586729-6.00524902s4.0112203 2.00174967 4.0000699 6.00524902v1.99475098m-8.0000699 0h8.0225317c1.0543618 0 1.9181652.81587779 1.9945143 1.8507377l.0054778.1548972-.0169048 6c-.0031058 1.1023652-.8976224 1.9943651-1.999992 1.9943651h-8.005627c-1.1045695 0-2-.8954305-2-2v-6c0-1.1045695.8954305-2 2-2z" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/><circle cx="6.5" cy="13.5" fill="currentColor" r="1.5"/></g></svg>\
                              </div>\
                           </div>\
                        </div>\
                        <div class="InputItem">\
                           <div class="View">\
                              <span> '+pageLang(1977)+' </span>\
                              <div class="Input" name="firstName"></div>\
                              <div class="BtnEdit fa fa-pencil">  </div>\
                           </div>\
                           <div class="Edit">\
                              <span> '+pageLang(1977)+' </span>\
                              <input name="firstName"/>\
                              <div style="display:flex;flex-direction: row-reverse;justify-content: space-between;">\
                              <div class="BtnLine"> '+pageLang(1983)+' </div>\
                              <div class="BtnEdit" T="0"> '+pageLang(1984)+' </div>\
                              </div>\
                           </div>\
                        </div>\
                        <div class="InputItem">\
                           <div class="View">\
                              <span> '+pageLang(1978)+' </span>\
                              <div class="Input" name="middleName"></div>\
                              <div class="BtnEdit fa fa-pencil">  </div>\
                           </div>\
                           <div class="Edit">\
                              <span> '+pageLang(1978)+' </span>\
                              <input name="middleName"/>\
                              <div style="display:flex;flex-direction: row-reverse;justify-content: space-between;">\
                              <div class="BtnLine"> '+pageLang(1983)+' </div>\
                              <div class="BtnEdit" T="0"> '+pageLang(1984)+' </div>\
                              </div>\
                           </div>\
                        </div>\
                        <div class="InputItem">\
                           <div class="View">\
                              <span> '+pageLang(1979)+' </span>\
                              <div class="Input" name="lastName"></div>\
                              <div class="BtnEdit fa fa-pencil">  </div>\
                           </div>\
                           <div class="Edit">\
                              <span> '+pageLang(1979)+' </span>\
                              <input name="lastName"/>\
                              <div style="display:flex;flex-direction: row-reverse;justify-content: space-between;">\
                              <div class="BtnLine"> '+pageLang(1983)+' </div>\
                              <div class="BtnEdit" T="0"> '+pageLang(1984)+' </div>\
                              </div>\
                           </div>\
                        </div>\
                        <div class="InputItem">\
                           <div class="View">\
                              <span> '+pageLang(1980)+' </span>\
                              <div class="Input" name="phone"></div>\
                              <div class="BtnEdit fa fa-pencil">  </div>\
                           </div>\
                           <div class="Edit">\
                              <span> '+pageLang(1980)+' </span>\
                              <input name="phone" type="tel" id="phone"/>\
                              <div style="display:flex;flex-direction: row-reverse;justify-content: space-between;">\
                              <div class="BtnLine"> '+pageLang(1983)+' </div>\
                              <div class="BtnEdit" T="0"> '+pageLang(1984)+' </div>\
                              </div>\
                           </div>\
                        </div>\
                        <div class="InputItem">\
                           <div class="View">\
                              <span> '+pageLang(1981)+' </span>\
                              <div class="Input" name="birthdate"></div>\
                              <div class="BtnEdit fa fa-pencil">  </div>\
                           </div>\
                           <div class="Edit">\
                              <span> '+pageLang(1981)+' </span>\
                              <div>\
                              <select name="birthdateDay">\
                                 <option value="01"> 01 </option>\
                                 <option value="02"> 02 </option>\
                                 <option value="03"> 03 </option>\
                                 <option value="04"> 04 </option>\
                                 <option value="05"> 05 </option>\
                                 <option value="06"> 06 </option>\
                                 <option value="07"> 07 </option>\
                                 <option value="08"> 08 </option>\
                                 <option value="09"> 09 </option>\
                                 <option value="10"> 10 </option>\
                                 <option value="11"> 11 </option>\
                                 <option value="12"> 12 </option>\
                                 <option value="13"> 13 </option>\
                                 <option value="14"> 14 </option>\
                                 <option value="15"> 15 </option>\
                                 <option value="16"> 16 </option>\
                                 <option value="17"> 17 </option>\
                                 <option value="18"> 18 </option>\
                                 <option value="19"> 19 </option>\
                                 <option value="20"> 20 </option>\
                                 <option value="21"> 21 </option>\
                                 <option value="22"> 22 </option>\
                                 <option value="23"> 23 </option>\
                                 <option value="24"> 24 </option>\
                                 <option value="25"> 25 </option>\
                                 <option value="26"> 26 </option>\
                                 <option value="27"> 27 </option>\
                                 <option value="28"> 28 </option>\
                                 <option value="29"> 29 </option>\
                                 <option value="30"> 30 </option>\
                                 <option value="31"> 31 </option>\
                              </select>\
                              <select name="birthdateMonth">\
                                 <option value="01"> '+defaultLang(2056)+' </option>\
                                 <option value="02"> '+defaultLang(2057)+' </option>\
                                 <option value="03"> '+defaultLang(2058)+' </option>\
                                 <option value="04"> '+defaultLang(2059)+' </option>\
                                 <option value="05"> '+defaultLang(2060)+' </option>\
                                 <option value="06"> '+defaultLang(2061)+' </option>\
                                 <option value="07"> '+defaultLang(2062)+' </option>\
                                 <option value="08"> '+defaultLang(2063)+' </option>\
                                 <option value="09"> '+defaultLang(2064)+' </option>\
                                 <option value="10"> '+defaultLang(2065)+' </option>\
                                 <option value="11"> '+defaultLang(2066)+' </option>\
                                 <option value="12"> '+defaultLang(2067)+' </option>\
                              </select>\
                              <select name="birthdateYear">\
                                 <option value="1930"> 1930 </option>\
                                 <option value="1931"> 1931 </option>\
                                 <option value="1932"> 1932 </option>\
                                 <option value="1933"> 1933 </option>\
                                 <option value="1934"> 1934 </option>\
                                 <option value="1935"> 1935 </option>\
                                 <option value="1936"> 1936 </option>\
                                 <option value="1937"> 1937 </option>\
                                 <option value="1938"> 1938 </option>\
                                 <option value="1939"> 1939 </option>\
                                 <option value="1940"> 1940 </option>\
                                 <option value="1941"> 1941 </option>\
                                 <option value="1942"> 1942 </option>\
                                 <option value="1943"> 1943 </option>\
                                 <option value="1944"> 1944 </option>\
                                 <option value="1945"> 1945 </option>\
                                 <option value="1946"> 1946 </option>\
                                 <option value="1947"> 1947 </option>\
                                 <option value="1948"> 1948 </option>\
                                 <option value="1949"> 1949 </option>\
                                 <option value="1950"> 1950 </option>\
                                 <option value="1951"> 1951 </option>\
                                 <option value="1952"> 1952 </option>\
                                 <option value="1953"> 1953 </option>\
                                 <option value="1954"> 1954 </option>\
                                 <option value="1955"> 1955 </option>\
                                 <option value="1956"> 1956 </option>\
                                 <option value="1957"> 1957 </option>\
                                 <option value="1958"> 1958 </option>\
                                 <option value="1959"> 1959 </option>\
                                 <option value="1960"> 1960 </option>\
                                 <option value="1961"> 1961 </option>\
                                 <option value="1962"> 1962 </option>\
                                 <option value="1963"> 1963 </option>\
                                 <option value="1964"> 1964 </option>\
                                 <option value="1965"> 1965 </option>\
                                 <option value="1966"> 1966 </option>\
                                 <option value="1967"> 1967 </option>\
                                 <option value="1968"> 1968 </option>\
                                 <option value="1969"> 1969 </option>\
                                 <option value="1970"> 1970 </option>\
                                 <option value="1971"> 1971 </option>\
                                 <option value="1972"> 1972 </option>\
                                 <option value="1973"> 1973 </option>\
                                 <option value="1974"> 1974 </option>\
                                 <option value="1975"> 1975 </option>\
                                 <option value="1976"> 1976 </option>\
                                 <option value="1977"> 1977 </option>\
                                 <option value="1978"> 1978 </option>\
                                 <option value="1979"> 1979 </option>\
                                 <option value="1980"> 1980 </option>\
                                 <option value="1981"> 1981 </option>\
                                 <option value="1982"> 1982 </option>\
                                 <option value="1983"> 1983 </option>\
                                 <option value="1984"> 1984 </option>\
                                 <option value="1985"> 1985 </option>\
                                 <option value="1986"> 1986 </option>\
                                 <option value="1987"> 1987 </option>\
                                 <option value="1988"> 1988 </option>\
                                 <option value="1989"> 1989 </option>\
                                 <option value="1990"> 1990 </option>\
                                 <option value="1991"> 1991 </option>\
                                 <option value="1992"> 1992 </option>\
                                 <option value="1993"> 1993 </option>\
                                 <option value="1994"> 1994 </option>\
                                 <option value="1995"> 1995 </option>\
                                 <option value="1996"> 1996 </option>\
                                 <option value="1997"> 1997 </option>\
                                 <option value="1998"> 1998 </option>\
                                 <option value="1999"> 1999 </option>\
                                 <option value="1990"> 1990 </option>\
                                 <option value="2000"> 2000 </option>\
                                 <option value="2001"> 2001 </option>\
                                 <option value="2002"> 2002 </option>\
                                 <option value="2003"> 2003 </option>\
                                 <option value="2004"> 2004 </option>\
                                 <option value="2005"> 2005 </option>\
                                 <option value="2006"> 2006 </option>\
                                 <option value="2007"> 2007 </option>\
                                 <option value="2008"> 2008 </option>\
                                 <option value="2009"> 2009 </option>\
                                 <option value="2010"> 2010 </option>\
                                 <option value="2011"> 2011 </option>\
                                 <option value="2012"> 2012 </option>\
                                 <option value="2013"> 2013 </option>\
                                 <option value="2014"> 2014 </option>\
                                 <option value="2015"> 2015 </option>\
                                 <option value="2016"> 2016 </option>\
                                 <option value="2017"> 2017 </option>\
                                 <option value="2018"> 2018 </option>\
                                 <option value="2029"> 2029 </option>\
                                 <option value="2020"> 2020 </option>\
                                 <option value="2020"> 2020 </option>\
                              </select>\
                              </div>\
                              <div style="display:flex;flex-direction: row-reverse;justify-content: space-between;">\
                              <div class="BtnLine"> '+pageLang(1983)+' </div>\
                              <div class="BtnEdit" T="1"> '+pageLang(1984)+' </div>\
                              </div>\
                           </div>\
                        </div>\
                        <div class="InputItem">\
                           <div class="View">\
                              <span> '+pageLang(1982)+' </span>\
                              <div class="Input" name="language"></div>\
                              <div class="BtnEdit fa fa-pencil">  </div>\
                           </div>\
                           <div class="Edit">\
                              <span> '+pageLang(1982)+' </span>\
                              <select name="language">\
                                 <option value=""> Seç </option>\
                              </select>\
                              <div style="display:flex;flex-direction: row-reverse;justify-content: space-between;">\
                              <div class="BtnLine"> '+pageLang(1983)+' </div>\
                              <div class="BtnEdit" T="1"> '+pageLang(1984)+' </div>\
                              </div>\
                           </div>\
                        </div>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         </div>\
      </article>\
      ').appendTo(".PageContentArea")

      var WW = parseInt($(window).width())
      var WH = parseInt($(window).height()) - 70
      $(".Account>.Right").css({"height":WH+"px"})

      if(WW<980){
         $(".Header .Left").html("<a href='/student-library' class='BtnBookList'><i></i> <span> "+pageLang(1985)+" </span></a>")
      }

      var input = document.querySelector("#phone");
      window.intlTelInput(input, {
      utilsScript: "ntl-tel-input.com/node_modules/intl-tel-input/build/js/utils.js?22",
      });

      var systemUser = JSON.parse(localStorage.getItem("systemUser"))
      var userType   = systemUser.type

         $(".View>.BtnEdit").click(function(){
            $(this).parent().parent().addClass("Show")
         })
         $(".Edit .BtnLine").click(function(){
            $(this).parent().parent().parent().removeClass("Show")
         })

         $(".Edit .BtnEdit").click(function(){
            var Type    = $(this).attr("T")
            if(Type==0){
               var Field   = $(this).parent().find("input").attr("name")
               var value   = $(this).parent().find("input").val()
            }
            if(Type==1){
               var Field   = $(this).parent().parent().find("select").attr("name")
               var value   = $(this).parent().parent().find("select").val()
            }

            if(Field=="firstName"){ 
               $('[name="firstName"]').val(value).html(value) 
            }
            if(Field=="middleName"){ 
               $('[name="middleName"]').val(value).html(value) 
            }
            if(Field=="lastName"){ 
               $('[name="lastName"]').val(value).html(value) 
            }
            if(Field=="birthdateDay"){ 
               var birthdateYear       = $('[name="birthdateYear"]').val()
               var birthdateMonth      = $('[name="birthdateMonth"]').val()
               var birthdateDay        = $('[name="birthdateDay"]').val()
               value                   = birthdateYear+"-"+birthdateMonth+"-"+birthdateDay
               Field                   = "birthdate"
               $('[name="birthdate"]').val(value).html(value) 
            }

            $.ajax({
            type: "post",
            url: systemApp+"user/profilUpdate",
            dataType: "json",
            data : "id="+systemUser.user.id+"&"+Field+"="+value+"",
            success: function(data) {
               notificationModal("success",pageLang(1986),pageLang(1987))
               Loading()
               localStorage.setItem("systemUserLanguage",value)
               userRehresh()
            }
            });

            $(this).parent().parent().removeClass("Show")
         })

         var UserRecordLang = systemUser.user.language
         if(UserRecordLang=="" || UserRecordLang==null){ UserRecordLang = userLang }
         $.ajax({
         type: "post",
         url: systemApp+"library/language/",
         dataType: "json",
         data : "status=1",
         success: function(data) {
            $.each(data, function( i, itemx ) {
               if(itemx.status==1){
                  $('<option value="'+itemx.code+'">'+itemx.name+'</option>').appendTo("select[name='language']")
                  $('[name="language"]>option[value="'+UserRecordLang+'"]').prop("selected",true)
                  if(itemx.code==UserRecordLang){
                        $(".Input[name='language']").html('\
                        <div>\
                           <span>'+itemx.flag+'</span>\
                           <span>'+itemx.name+'</span>\
                        </div>\
                        ')
                  }
               }
            });
         }
         });

         //"1993-06-25"
         var UserRecordBirthDate = systemUser.user.birthdate
         if(systemUser.user.birthdate=="" || systemUser.user.birthdate==null){ UserRecordBirthDate = "" }
         if(UserRecordBirthDate!=""){
            var BI = UserRecordBirthDate.split("-")
            var birthdateYear    =  BI[0]
            var birthDateMonth   =  BI[1]
            var birthDateDay     =  BI[2]
            $('[name="birthdateYear"]>option[value="'+birthdateYear+'"]').prop("selected",true)
            $('[name="birthdateMonth"]>option[value="'+birthDateMonth+'"]').prop("selected",true)
            $('[name="birthdateDay"]>option[value="'+birthDateDay+'"]').prop("selected",true)
         }

      
      $('.Account>.Left>.Avatar>img').attr("src",systemUser.user.avatar)
      $('[name="UserId"]').val(systemUser.user.id).html(systemUser.user.id)
      $('[name="Mail"]').val(systemUser.user.mail).html(systemUser.user.mail)
      $('[name="firstName"]').val(systemUser.user.firstName).html(systemUser.user.firstName)
      $('[name="middleName"]').val(systemUser.user.middleName).html(systemUser.user.middleName)
      $('[name="lastName"]').val(systemUser.user.lastName).html(systemUser.user.lastName)
      $('[name="phone"]').val(systemUser.user.phone).html(systemUser.user.phone)
      $('[name="birthdate"]').val(systemUser.user.birthdate).html(systemUser.user.birthdate)
      $(".Info>.Name").html(systemUser.user.firstName+' '+systemUser.user.lastName)
      $(".Info>.Id").html(systemUser.user.id)
